#include <stdio.h>
#include <stdlib.h>
#include "cola.h"

void graphColour(int k, int m, aluno *alunos, aluno **M, int numero_alunos)
{
    int c=1;
    int i;
   for(m=1;m<numero_alunos;m++){
    for(c=1;c<=m;c++){
        if(isSafe(k, c, numero_alunos, M, alunos)){
            alunos[k].cor=c;
            if(k+1<numero_alunos)
                graphColour(k+1, m, alunos, M, numero_alunos);
            //else
              //  for(i=0;i<numero_alunos;i++){
                //    printf("%d ", alunos[i].cor);
              //  }
        }

    }
   }
}
int isSafe(int k, int c, int numero_alunos, aluno **M, aluno *alunos)
{
    int i;
    for(i=0; i<numero_alunos; i++) {
       if(M[k][i].cola==1&&c == alunos[i].cor){
            return 0; //falso
       }
    }
        return 1; //verdadeiro
}




aluno *aloca_vetor(int numero_alunos)
{
    aluno *alunos;
    alunos = (aluno*)malloc(numero_alunos*sizeof(aluno));
    return alunos;
}

int *aloca_vetor_i(int numero_alunos)
{
    int *vetor;
    vetor = (int *)malloc(numero_alunos*sizeof(int));
    return vetor;
}

aluno **aloca_matriz(int numero_alunos)
{
    int lin;
    aluno **M;
    M = (aluno**)malloc(numero_alunos*sizeof(aluno*)); //aloca as linhas
    for(lin=0; lin<numero_alunos; lin++)
    {
        M[lin] = (aluno*)malloc(numero_alunos*sizeof(aluno));//aloca as colunas
    }
    return M;

}

void limpa_cor(aluno *alunos, int numero_alunos)
{
    int j;
    for(j=0; j<numero_alunos; j++)
    {
        alunos[j].cor=0;
    }

}

aluno *organizaTurma (aluno *alunos, int numero_alunos) {

	int i, ver=1;
	aluno temp;
		do{
		     for(i=1; i<numero_alunos; i++){
				if(alunos[i].cor<alunos[i-1].cor) {
					temp = alunos[i-1];
					alunos[i-1]=alunos[i];
					alunos[i]=temp;
				}
			}
			for(i=1; i<numero_alunos; i++){
				if(alunos[i].cor<alunos[i-1].cor) {
					ver=0;
				}
			}
		}while(ver=0);
/*	printf("\n\nVetor organizado:\n");
	for(i=0; i<numero_alunos; i++){
		printf("\t%d",alunos[i].cor);
	}
*/
	return alunos;
	
}
