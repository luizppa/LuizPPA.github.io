#define MAX 20


typedef struct{
	int numero;
	int  cor;
	char nome[MAX];
	int cola;
}aluno;

void graphColour(int k, int m, aluno *alunos, aluno **M, int numero_alunos);
int isSafe(int k, int c, int numero_alunos, aluno **M, aluno *alunos);
aluno *aloca_vetor(int numero_alunos);
aluno **aloca_matriz(int numero_alunos);
aluno *organizaTurma (aluno *alunos, int numero_alunos);
int *aloca_vetor_i(int numero_alunos);
