Dupla: Ilmer e Luiz
Trabalho: O Problema da Cola


----------------------------------------------------------------------------------------------------
|Digite a entrada no arquivo de texto no seguinte formato:							   |
|																   |
|(Número de alunos, por exemplo 7)										         |
|(nome do aluno 1)													   |
|(nome do aluno 2)      obs.: Os nomes devem conter um máximo de 20 caracteres sem espaço          |
|(nome do aluno 3)		     (mas para a impressão da turma no arquivo de saida ficar show   |
|	...			     é melhor que os nomes tenham cerca de 6 ou 7 caracteres no máximo)    |
|(nome do aluno 7)      												   |
----------------------------------------------------------------------------------------------------

A saída do programa é apresentada no arquivo saida.txt, o arquivo tempo.txt apresenta o tempo de execussão do algorítimo para diferentes números de alunos.

----------------------------------------------------------------------------------------------------
							Área para choro

A gente só não quer tomar bomba...























Dica: Experimente colocar o nome "Virginia" em algum dos alunos...
