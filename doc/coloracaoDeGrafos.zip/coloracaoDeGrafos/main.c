#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "cola.h"
#define MAX 20


int main(){
    ///////////////VARI�VEIS///////////////
    aluno **M, *alunos, *turma;
    int lin, col, i, entradar;
    float cola, tempo;
    int numero_alunos;
    int m=1, k=0;
    char enter;
    char bomba[9] = {"Virginia"};	
    int watch=1;
	clock_t t;
	FILE *entrada;
	FILE *saida;
	FILE *executionTime;
	srand(time(NULL));

	entrada=fopen("entrada.txt", "r");
	if(entrada==NULL){
		printf("\n404: Arquivo de entrada nao encontrado...");
		usleep(5000000);
		exit(42);
	}
	saida  =fopen("saida.txt", "w+");
      executionTime = fopen("tempo.txt", "a+");
    //////////////APRESENTA��O//////////////
	printf("      ___           ___          _____          ___                         \n");
	printf("     /  /\\         /  /\\        /  /::\\        /  /\\                    \n");
	printf("    /  /::\\       /  /:/_      /  /:/\\:\\      /  /:/_                    \n");
	printf("   /  /:/\\:\\     /  /:/ /\\    /  /:/  \\:\\    /  /:/ /\\                \n");
	printf("  /  /:/~/::\\   /  /:/ /:/_  /__/:/ \\__\\:|  /  /:/ /::\\                 \n");
	printf(" /__/:/ /:/\\:\\ /__/:/ /:/ /\\ \\  \\:\\ /  /:/ /__/:/ /:/\\:\\            \n");
	printf(" \\  \\:\\/:/__\\/ \\  \\:\\/:/ /:/  \\  \\:\\  /:/  \\  \\:\\/:/~/:/       \n");
	printf("  \\  \\::/       \\  \\::/ /:/    \\  \\:\\/:/    \\  \\::/ /:/            \n");
	printf("   \\  \\:\\        \\  \\:\\/:/      \\  \\::/      \\__\\/ /:/            \n");
	printf("    \\  \\:\\        \\  \\::/        \\__\\/         /__/:/                \n");
	printf("     \\__\\/         \\__\\/                       \\__\\/    \n");
	printf("\n Dupla: Ilmer Oliveira & Luiz Philippe\n\nPressione enter para continuar...");
	__fpurge(stdin);
	scanf("%c", &enter);
	system("clear");

    ////////////////////////////////////////
    //printf("Insira a quantidade de alunos:\n");
    fscanf(entrada, "%d", &numero_alunos);


    M = aloca_matriz(numero_alunos);
    alunos = aloca_vetor(numero_alunos);

    ///////////////////////////////////////


    for(i=0;i<numero_alunos;i++){
	if(feof(entrada)){
		printf("\nA entrada foi inserida incorretamente...\nSaindo do programa com o valor 42. (Enter para continuar)\n");
		__fpurge(stdin);
		scanf("%c", &enter);
		exit(42);
	}
        alunos[i].numero=i;
        fscanf(entrada, "%s\n", alunos[i].nome);
	if (strcmp(alunos[i].nome, bomba)==0){
		watch=0;
	}

    }
    for(lin=0;lin<numero_alunos;lin++){
        for(col=0;col<numero_alunos;col++){
           if(col==lin){
            M[lin][col].cola=1;
           }
            if(col>lin){
                printf("Qual a chance de cola entre o aluno %s e o aluno %s?\n", alunos[lin].nome, alunos[col].nome);
                scanf("%f", &cola);
                if(cola>0.5){
                    M[lin][col].cola=1;
                    M[col][lin].cola=1;
                        }
                 else
                     M[lin][col].cola=0;
			 }
            }
    }
    t=clock();
    graphColour(k, m,  alunos,  M, numero_alunos);
    t=clock()-t;
    tempo=((float)t)/CLOCKS_PER_SEC;
    fprintf(executionTime, "\n%d\t\t%f segundos", numero_alunos, tempo);
 ///////////////////////////////////////////////////////

	fprintf(saida, "\n/////MATRIZ DE ADJAC�NCIA////\n\n");
    for(lin=0;lin<numero_alunos;lin++){
        for(col=0;col<numero_alunos;col++){
		fprintf(saida, "%d ", M[lin][col].cola);
        }
	  fprintf(saida, "\n");
    }

fprintf(saida, "\n////VETOR////\n\nNome\t\t\tTipo da prova\n\n");

    for(lin=0;lin<numero_alunos;lin++){
   fprintf(saida, "%s\t\t\t%d\n", alunos[lin].nome, alunos[lin].cor);
    }
    turma=organizaTurma(alunos, numero_alunos);
    fprintf(saida, "\n\nA organizacao sugerida para a turma eh:\n\n");
    for(i=0; i<numero_alunos; i++){
		if(i!=0&&i%3==0){
			fprintf(saida, "\n\n%s\t\t",alunos[i].nome);
		}
		else fprintf(saida, "%s\t\t",alunos[i].nome);
    }

	fclose(saida);
	fclose(entrada);
	fclose(executionTime);
	if(watch==0){
	fprintf(saida, "\n\nYOU SHALL NOT PASS!\n\n");
	printf("\n\n      YOU SHALL NOT PASS!!\n\n");
	printf("             #                        \n");
	printf("            ,#, ,#                    \n");
	printf("        #########\"                   \n");
	printf("         '\"####\"                    \n");
	printf("         ,######,                     \n");
	printf("         #\" ##\"##                   \n");
	printf("            \\  \\        ___         \n");
	printf("             \\  '===..�\"   \"\".    \n");
	printf("              \"�.__    ,---.  \\     \n");
	printf("                   \"\"\"\"    :  |   \n");
	printf("                          /   '       \n");
	printf("           __========__.'\"-, /       \n");
	printf("        ,-'            '-,  ',        \n");
	printf("      ,'                  ',.'        \n");
	printf("     /                      \\        \n");
	printf("    .                        .        \n");
	printf("    |                        |        \n");
	printf("    |                        |        \n");
	printf("    |                        |        \n");
	printf("    '                        '        \n");
	printf("     \\                      /        \n");
	printf("      '.                  .'          \n");
	printf("        '-.__        __.-'            \n");
	printf("             \"\"\"\"\"\"\"\"         \n");
	}
   return 0;
}

