package trabalho1;

public interface FuncionarioRemunerado {

    public void pagamento();
    public void bonificacao();
}
