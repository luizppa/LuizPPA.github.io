package trabalho1;

public class Trabalho1 {

    public static void main(String[] args) {
       
    }
    
}
