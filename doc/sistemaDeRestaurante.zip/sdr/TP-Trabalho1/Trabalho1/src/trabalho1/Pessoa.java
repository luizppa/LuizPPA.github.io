package trabalho1;

public class Pessoa {

    protected String nome;
    protected String cpf;
    protected int idade;
    protected Data dataDeNascimento;
    protected double capital;
}
